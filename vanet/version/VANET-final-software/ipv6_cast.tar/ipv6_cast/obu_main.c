#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <net/if.h>
#include <stdlib.h>
#include <netinet/icmp6.h>
#include <sys/time.h>

#include "ipv6_cast.h"

struct cmd_info {
	char nodename[NODE_NAME_LEN];
	char nodeaddr[INET6_ADDRSTRLEN];
	char seq[BUFLEN_SHORT];
};

char minename[NODE_NAME_LEN];
static unsigned int outif;
int CD_lsn_fd = -1; // Waiting for C&D module command,	OBU(myself) <- C&D
int CD_snd_fd = -1; // Sending messages to C&D module,	OBU(myself) -> C&D
int obu_lsn_fd = -1; // Waiting for peer OBU's message,	OBU(myself) <- OBU(peer)
int obu_snd_fd = -1; // Sending messages to peer OBU,	OBU(myself) -> OBU(peer)
int obu_lsn_bcast_fd = -1; // Waiting for broadcast OBU's message, OBU(myself) <- Broadcast
int obu_snd_bcast_fd = -1; // Sending broadcast message, OBU(myself) -> Broadcast
struct sockaddr_in6 obu_lsn_sa;
struct sockaddr_in6 obu_snd_sa;
struct sockaddr_in6 obu_lsn_bcast_sa;
struct sockaddr_in6 obu_snd_bcast_sa;
unsigned int obu_lsn_salen;
unsigned int obu_snd_salen;
unsigned int obu_lsn_bcast_salen;
unsigned int obu_snd_bcast_salen;

int init_CD_rel(const char *cd_addr)
{
	CD_snd_fd = udp_connect(cd_addr, CTRL_DISP_PORT);
	if (CD_snd_fd < 0) {
		fprintf(stderr, "%s: udp connect to %s <%d> failed\n", __func__,
				cd_addr, CTRL_DISP_PORT);
		return -1;
	}

	CD_lsn_fd = udp_bind(NULL, OBU_CONTROL_PORT);
	if (CD_lsn_fd < 0) {
		fprintf(stderr, "%s: udp bind port <%d> for C&D failed\n",
				__func__, OBU_CONTROL_PORT);
		return -1;
	}

	return 0;
}

int init_obu_rel()
{
	struct ipv6_mreq mreq6;
	int val;

	/**
	 * obu_lsn_fd initial
	 */
	obu_lsn_fd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (obu_lsn_fd < 0) {
		fprintf(stderr, "%s: socket failed\n", __func__);
		return -1;
	}
	obu_lsn_salen = sizeof(struct sockaddr_in6);
	bzero(&obu_lsn_sa, obu_lsn_salen);
	obu_lsn_sa.sin6_family = AF_INET6;
	obu_lsn_sa.sin6_port = htons(OBU_LISTEN_PORT);
	if (bind(obu_lsn_fd, (struct sockaddr *)&obu_lsn_sa, obu_lsn_salen) < 0) {
		fprintf(stderr, "%s: bind failed\n", __func__);
		return -1;
	}

	/**
	 * obu_snd_fd initial
	 */
	obu_snd_fd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (obu_snd_fd < 0) {
		fprintf(stderr, "%s: socket failed\n", __func__);
		return -1;
	}
	obu_snd_salen = sizeof(struct sockaddr_in6);
	bzero(&obu_snd_sa, obu_snd_salen);
	obu_snd_sa.sin6_family = AF_INET6;
	obu_snd_sa.sin6_port = htons(OBU_LISTEN_PORT);
	if ((outif = if_nametoindex(VANET_DEVICE_NAME)) == 0) {
		warning(VANET_DEVICE_NAME);
		fprintf(stderr, "%s: get device outif failed\n", __func__);
		return -1;
	}
	// obu_snd_sa.sin6_addr should completed when we know whom we will communicate with.
	obu_snd_sa.sin6_scope_id = outif;

	/**
	 * obu_lsn_bcast_fd initial
	 */
	obu_lsn_bcast_fd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (obu_lsn_bcast_fd < 0) {
		fprintf(stderr, "%s: socket failed\n", __func__);
		return -1;
	}
	obu_lsn_bcast_salen = sizeof(struct sockaddr_in6);
	bzero(&obu_lsn_bcast_sa, obu_lsn_bcast_salen);
	obu_lsn_bcast_sa.sin6_family = AF_INET6;
	obu_lsn_bcast_sa.sin6_port = htons(OBU_LISTEN_BCAST_PORT);
	if (bind(obu_lsn_bcast_fd, (struct sockaddr *)&obu_lsn_bcast_sa, obu_lsn_bcast_salen) < 0) {
		fprintf(stderr, "%s: bind failed\n", __func__);
		return -1;
	}
	// multicast group join
	mreq6.ipv6mr_interface = outif;
	if (inet_pton(AF_INET6, OBU_LISTEN_BCAST_ADDR, &mreq6.ipv6mr_multiaddr) != 1) {
		fprintf(stderr, "%s: invalid obu listen broadcast address\n", __func__);
		return -1;
	}
	setsockopt(obu_lsn_bcast_fd, IPPROTO_IPV6, IPV6_JOIN_GROUP, &mreq6, sizeof(mreq6));

	/**
	 * obu_snd_bcast_fd initial
	 */
	obu_snd_bcast_fd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (obu_snd_bcast_fd < 0) {
		fprintf(stderr, "%s: socket failed\n", __func__);
		return -1;
	}
	// multicast set
	setsockopt(obu_snd_bcast_fd, IPPROTO_IPV6, IPV6_MULTICAST_IF, &outif, sizeof(outif));
	val = 0;
	setsockopt(obu_snd_bcast_fd, IPPROTO_IPV6, IPV6_MULTICAST_LOOP, &val, sizeof(val));
	val = VANET_BCAST_HOPLIMIT_DEFAULT;
	setsockopt(obu_snd_bcast_fd, IPPROTO_IPV6, IPV6_MULTICAST_HOPS, &val, sizeof(val));
	obu_snd_bcast_salen = sizeof(struct sockaddr_in6);
	bzero(&obu_snd_bcast_sa, obu_snd_bcast_salen);
	obu_snd_bcast_sa.sin6_family = AF_INET6;
	obu_snd_bcast_sa.sin6_port = htons(OBU_LISTEN_BCAST_PORT);
	if (inet_pton(AF_INET6, OBU_LISTEN_BCAST_ADDR, &obu_snd_bcast_sa.sin6_addr) != 1) {
		fprintf(stderr, "%s: invalid obu listen broadcast address\n", __func__);
		return -1;
	}

	return 0;
}

void close_all_fd()
{
	close(CD_snd_fd);
	close(CD_lsn_fd);
	close(obu_snd_fd);
	close(obu_lsn_fd);
	close(obu_lsn_bcast_fd);
	close(obu_snd_bcast_fd);
}

/**
 * Listen peer OBU's message, and resend message to Control & Display module.
 */
void *thr_lsn_peer_obu()
{
	struct sockaddr_in6 tmpsa;
	unsigned int tmpsalen;
	char buf[BUFLEN];
	char addr[INET6_ADDRSTRLEN];
	int nrecv, nsend;

	while (1) {
		memset(buf, 0, sizeof(buf));
		if ((nrecv = recvfrom(obu_lsn_fd, buf, BUFLEN, 0, (struct sockaddr *)&tmpsa, &tmpsalen)) < 0) {
			warning("Recvfrom");
		} else {
			if (inet_ntop(AF_INET6, &tmpsa.sin6_addr, addr, tmpsalen) == 0)
				warning("Get peer OBU's address failed");

			// Print peer OBU's message in PowerPC console
			fprintf(stdout, "RECV: <%s> %s", addr, buf);

			// Resend peer OBU's message to C&D module
			nsend = sendto(CD_snd_fd, buf, nrecv, MSG_DONTWAIT, NULL, 0);
			if (nsend == nrecv) {
				fprintf(stdout, "Message resend to C&D\n");
			} else {
				warning("Sendto");
				fprintf(stderr, "Resent to C&D failed\n");
				break;
			}
		}
	}

	close_all_fd();
	exit(-1);
}

/**
 * Listen broadcast OBU's message, and resend message to Control & Display module.
 * Broadcast OBU's message is always emergent alert.
 */
void *thr_lsn_broadcast_obu()
{
	struct sockaddr_in6 tmpsa;
	unsigned int tmpsalen;
	char buf[BUFLEN];
	char addr[INET6_ADDRSTRLEN];
	int nrecv, nsend;

	while (1) {
		bzero(buf, BUFLEN);
		if ((nrecv = recvfrom(obu_lsn_bcast_fd, buf, BUFLEN, 0, (struct sockaddr *)&tmpsa, &tmpsalen)) < 0) {
			warning("Recvfrom obu broadcast failed");
		} else {
			if (inet_ntop(AF_INET6, &tmpsa.sin6_addr, addr, tmpsalen) == 0)
				warning("Get broadcast OBU's address failed");

			// Print broadcast OBU's message in PowerPC console
			fprintf(stdout, "RECV BCAST: <%s> %s", addr, buf);

			// Resend broadcast OBU's message to C&D module
			nsend = sendto(CD_snd_fd, buf, nrecv, MSG_DONTWAIT, NULL, 0);
			if (nsend == nrecv) {
				fprintf(stdout, "Broadcast message resend to C&D\n");
			} else {
				warning("Sendto");
				fprintf(stderr, "Resent to C&D failed\n");
				break;
			}
		}
	}

	close_all_fd();
	exit(-1);
}

/**
 * Text message using main thread process and do not generate new thread
 */
int text_message_send(struct msghdr *m, const char *dstaddr, const char *data, int bcast, unsigned int bcc)
{
	struct sockaddr_in6 *sa = (struct sockaddr_in6 *)(m->msg_name);
	struct iovec *iov = m->msg_iov;
	unsigned int fl;
	struct flowlabel_control *fc;

	fprintf(stderr, "DEBUG: %s to <%s> <%s>\n", __func__, dstaddr, data);
	bzero(iov->iov_base, BUFLEN);
	iov->iov_len = strlen(data);
	if (iov->iov_len > BUFLEN) {
		fprintf(stderr, "Error: text message data length exceeds %d\n", BUFLEN);
		return -1;
	}
	sprintf(iov->iov_base, "%s", data);

	if (bcast) { // Broadcast
		fl = htonl(bcc & 0xfffff); // wrap bcast_count
		fc = (struct flowlabel_control *)(m->msg_control);
		memcpy((fc->cmsg_data), (unsigned char *)&fl, sizeof(fc->cmsg_data));
		if (sendmsg(obu_snd_bcast_fd, m, 0) < 0) {
			warning("Sendmsg broadcast text message failed\n");
			return -1;
		}
	} else { // Unicast
		if (inet_pton(AF_INET6, dstaddr, &(sa->sin6_addr)) != 1) {
			warning("Address");
			return -1;
		}
		if (sendmsg(obu_snd_fd, m, VANET_SENDMSG_FLAG) < 0) {
			warning("Sendmsg");
			return -1;
		}
	}

	fprintf(stderr, "DEBUG: %s finished\n", __func__);
	return 0;
}

/**
 * RTT test would generate new thread to work
 */

void *thr_rtt_test(void *arg)
{
	struct cmd_info ci;
	int sockfd;
	struct sockaddr_in6 dstsa, tmpsa;
	socklen_t salen;
	struct msghdr msg;
	struct iovec iov;
	struct timeval tval;
	struct timeval *tvsend;
	char buf[BUFLEN], buf2[BUFLEN];
	char result[BUFLEN_SHORT];
	int len;
	struct icmp6_filter myfilt;
	int on = 1;
	struct icmp6_hdr *icmp6;
	pid_t pid;
	double rtt;
	struct cmsghdr *cmsg;
	int hlim;
	char addrbuf[INET6_ADDRSTRLEN];
	unsigned int seq;

	pid = getpid() & 0xffff;
	bzero(&ci, sizeof(ci));
	memcpy(&ci, (struct cmd_info *)arg, sizeof(ci));
	// From now on ci is mine

	fprintf(stdout, "Start RTT-TEST %s<%s> seq=%s\t: %d bytes\n",
			ci.nodename, ci.nodeaddr, ci.seq, RTT_TEST_DATALEN);
	// Init
	salen = sizeof(dstsa);
	bzero(&dstsa, salen);
	bzero(&tmpsa, salen);
	dstsa.sin6_family = AF_INET6;
	if (inet_pton(AF_INET6, ci.nodeaddr, &dstsa.sin6_addr) != 1) {
		warning("Assign destIP address");
		return ((void *)0);
	}
	sockfd = socket(AF_INET6, SOCK_RAW, IPPROTO_ICMPV6);
	if (sockfd < 0) {
		warning("Socket");
		return ((void *)0);
	}
	setuid(getuid());
	ICMP6_FILTER_SETBLOCKALL(&myfilt);
	ICMP6_FILTER_SETPASS(ICMP6_ECHO_REPLY, &myfilt);
	setsockopt(sockfd, IPPROTO_IPV6, ICMP6_FILTER, &myfilt, sizeof(myfilt));
	setsockopt(sockfd, IPPROTO_IPV6, IPV6_RECVHOPLIMIT, &on, sizeof(on));
	on = 4 * BUFLEN;
	setsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &on, sizeof(on));

	// Send echo request
	bzero(buf, BUFLEN);
	icmp6 = (struct icmp6_hdr *)buf;
	icmp6->icmp6_type = ICMP6_ECHO_REQUEST;
	icmp6->icmp6_code = 0;
	icmp6->icmp6_id = pid;
	icmp6->icmp6_seq = atoi(ci.seq) & 0xFFFF;
	memset((icmp6+1), 0xa5, RTT_TEST_DATALEN);
	gettimeofday((struct timeval *)(icmp6+1), NULL);
	len = sizeof(struct icmp6_hdr) + RTT_TEST_DATALEN;
	if (sendto(sockfd, buf, len, VANET_SENDMSG_FLAG, (struct sockaddr *)&dstsa, salen) != len)
		warning("Sendto");

	// Receive echo reply
	bzero(buf, BUFLEN);
	iov.iov_base = buf;
	iov.iov_len = BUFLEN;
	msg.msg_name = &tmpsa;
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	bzero(buf2, BUFLEN);
	msg.msg_control = buf2;
	msg.msg_namelen = salen;
	msg.msg_controllen = BUFLEN;
	len = recvmsg(sockfd, &msg, 0);
	if (len < 8) {
		fprintf(stderr, "Recvmsg failed");
		return ((void *)0);
	}

	// Process echo reply
	gettimeofday(&tval, NULL);
	icmp6 = (struct icmp6_hdr *)buf;
	if (icmp6->icmp6_type != ICMP6_ECHO_REPLY)
		return ((void *)0);
	if (icmp6->icmp6_id != pid)
		return ((void *)0);
	if (len < 16)
		return ((void *)0);
	tvsend = (struct timeval *)(icmp6+1);
	tv_sub(&tval, tvsend);
	rtt = tval.tv_sec * 1000.0 + tval.tv_usec / 1000.0;
	hlim = -1;
	for (cmsg = CMSG_FIRSTHDR(&msg); cmsg != NULL; cmsg = CMSG_NXTHDR(&msg, cmsg)) {
		if (cmsg->cmsg_level == IPPROTO_IPV6 && cmsg->cmsg_type == IPV6_HOPLIMIT) {
			hlim = *(u_int32_t *)CMSG_DATA(cmsg);
			break;
		}
	}
	if (inet_ntop(AF_INET6, &(tmpsa.sin6_addr), addrbuf, salen) == NULL)
		sprintf(addrbuf, "NULL");
	fprintf(stdout, "%d bytes from <%s>: seq=%u, hlim=", len, addrbuf, icmp6->icmp6_seq);
	seq = icmp6->icmp6_seq;
	if (hlim == -1)
		fprintf(stdout, "???");
	else
		fprintf(stdout, "%d", hlim);
	sprintf(result, "%.3f", rtt);
	fprintf(stdout, ", rtt=%s ms\n", result);

	// Build RTT test result message to C&D
	bzero(buf, BUFLEN);
	sprintf(buf, "[%s] [0] S %u %s", ci.nodename, seq, result);
	on = strlen(buf);
	len = sendto(CD_snd_fd, buf, on, MSG_DONTWAIT, NULL, 0);
	if (len == on) {
		fprintf(stdout, "RTT test result send to C&D\n");
	} else {
		warning("RTT test result send to C&D failed");
	}
		
	return ((void *)0);
}

int rtt_test(const char *dstnode, const char *dstaddr, const char *seq)
{
	int err;
	pthread_t tid;
	/**
	 * Since recvbuf will be flush in serve_for_CD main process, rtt_test
	 * should store those stuff by itself.
	 */
	static struct cmd_info ci;

	bzero(&ci, sizeof(ci));
	strcpy(ci.nodename, dstnode);
	strcpy(ci.nodeaddr, dstaddr);
	strcpy(ci.seq, seq);

	err = pthread_create(&tid, NULL, thr_rtt_test, (void *)&ci);
	if (err != 0) {
		warning("Create rtt test thread failed");
		return -1;
	}
	err = pthread_detach(tid);
	if (err != 0) {
		warning("Detach thread failed");
		return -1;
	}

	fprintf(stdout, "RTT test thread generated...\n");

	return 0;
}

#define BW_TEST_TIMES 3 // Value calculating interval is 500ms
#define BW_TEST_SILENT_MAX (BW_TEST_TIMES * 1)
static double bw_test_rate[BW_TEST_TIMES]; // store bandwidth test result
static int bw_test_count = 0;
static int bw_test_total_bytes = 0;
static int bw_test_silent_times = 0;

// SIGALRM generated every 500ms
void bw_test_sig_alrm(int signo)
{
	if (signo != SIGALRM) {
		fprintf(stderr, "Unknown signo = %d\n", signo);
		return ;
	}
	if (bw_test_count >= BW_TEST_TIMES) {
		fprintf(stdout, "%s bandwidth test finished\n", __func__);
		return ;
	}
	// Even though SIGALRM is coming, I do not receive any bytes from peer OBU.
	if (bw_test_total_bytes <= 0) {
		bw_test_silent_times++;
		if (bw_test_silent_times >= BW_TEST_SILENT_MAX) {
			bw_test_count = BW_TEST_TIMES; // stop test
			fprintf(stdout, "%s bw set bw_test_count to BW_TEST_TIMES\n",
					__func__);
		}
		return ;
	}
	bw_test_rate[bw_test_count] = bw_test_total_bytes / 500.0;
	bw_test_count++;
	bw_test_total_bytes = 0;
}

/**
 * Do bandwidth test work, feed C&D a result absolutely.
 */
int do_bw_test(struct cmd_info *ci)
{
	int i, len;
	int sockfd;
	struct sockaddr_in6 recvsa, tmpsa;
	unsigned int salen;
	char buf[BUFLEN];
	int nrecv = 0;
	struct itimerval itval;
	int on;

	/**
	 * Initial
	 */
	for (i=0; i<BW_TEST_TIMES; i++)
		bw_test_rate[i] = 0.0;
	bw_test_count = 0;
	bw_test_total_bytes = 0;
	bw_test_silent_times = 0;
	salen = sizeof(struct sockaddr_in6);
	sockfd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (sockfd < 0) {
		warning("Socket");
		goto result;
	}
	bzero(&recvsa, salen);
	recvsa.sin6_family = AF_INET6;
	recvsa.sin6_port = htons(OBU_BW_TEST_PORT);
	on = 1;
	setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
	if (bind(sockfd, (struct sockaddr *)&recvsa, salen) < 0) {
		warning("Bind failed");
		goto result;
	}
	itval.it_value.tv_sec = 0;
	itval.it_value.tv_usec = 500000;
	itval.it_interval.tv_sec = 0;
	itval.it_interval.tv_usec = 500000;
	if (setitimer(ITIMER_REAL, &itval, NULL) < 0) {
		warning("Setitimer");
		goto result;
	}

	/**
	 * Calculate result
	 */
	while (bw_test_count < BW_TEST_TIMES) {
		if ((nrecv = recvfrom(sockfd, buf, BUFLEN, 0, (struct sockaddr *)&tmpsa, &salen)) < 0) {
			if (errno == EINTR)
				continue;
			warning("Recvfrom");
			nrecv = 0;
		}
		bw_test_total_bytes += nrecv;
	}

	// Unset SIGALRM generating
	itval.it_value.tv_sec = 0;
	itval.it_value.tv_usec = 0;
	if (setitimer(ITIMER_REAL, &itval, NULL) < 0)
		warning("Setitimer");

	/**
	 * Build and send result to C&D
	 */
	// Get bw test result in bw_test_rate[1]
result:
	close(sockfd);
	bzero(buf, BUFLEN);
	sprintf(buf, "[%s] [0] B %s %.3f", ci->nodename, ci->seq, bw_test_rate[1]);
	fprintf(stdout, "%s send to C&D: %s\n", __func__, buf);
	i = strlen(buf);
	len = sendto(CD_snd_fd, buf, i, MSG_DONTWAIT, NULL, 0);
	if (len == i) {
		fprintf(stdout, "BW test result send to C&D\n");
	} else {
		warning("BW test result send to C&D failed");
	}
	
	/**
	 * Finished
	 */
	return 0;
}

int bw_test_resp(const char *addr)
{
	int fd;
	struct sockaddr_in6 sa;
	int salen;
	char buf[BUFLEN];
	struct iovec iov;
	struct msghdr msg;
	union hoplimit_control hlc;
	unsigned char *cmdatap;
	struct timeval start, end;
	unsigned int count = 1;

	fd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (fd < 0) {
		warning("Socket");
		return -1;
	}
	salen = sizeof(struct sockaddr_in6);
	bzero(&sa, salen);
	sa.sin6_family = AF_INET6;
	sa.sin6_port = htons(OBU_BW_TEST_PORT);
	sa.sin6_scope_id = outif;
	if (inet_pton(AF_INET6, addr, &sa.sin6_addr) != 1) {
		fprintf(stderr, "%s assign destIP address failed\n", __func__);
		close(fd);
		return -1;
	}
	iov.iov_base = buf;
	iov.iov_len = BUFLEN;
	bzero(buf, BUFLEN);
	bzero(&msg, sizeof(msg));
	msg.msg_name = (struct sockaddr *)&sa;
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	msg.msg_namelen = salen;
	bzero(&hlc, sizeof(hlc));
	msg.msg_control = hlc.control;
	msg.msg_controllen = sizeof(hlc.control);
	hlc.cmsg.cmsg_len = CMSG_LEN(sizeof(int));
	hlc.cmsg.cmsg_level = IPPROTO_IPV6;
	hlc.cmsg.cmsg_type = IPV6_HOPLIMIT;
	cmdatap = CMSG_DATA(&(hlc.cmsg));
	*((int *)cmdatap) = VANET_UC_HOPLIMIT_DEFAULT;

	gettimeofday(&start, NULL); // start time of sending test packet
	while (1) {
		if (sendmsg(fd, &msg, VANET_SENDMSG_FLAG) < 0) {
			fprintf(stderr, "Send bw test packet failed\n");
			close(fd);
			return -1;
		}

		if ((count & 63) == 0) {
			gettimeofday(&end, NULL);
			if (end.tv_sec - start.tv_sec > 2) { // sendmsg alive at least 2 seconds.
				break; // stop sendmsg
			}
		}

		count++;
	}

	close(fd);

	return 0;
}

void *thr_resp_bw_test(void *arg)
{
	int fd;
	struct sockaddr_in6 sa, tmpsa;
	unsigned int salen;
	int len;
	char buf[BUFLEN];
	char addr[INET6_ADDRSTRLEN];

	/**
	 * Initial socket and sockaddr
	 */
	fd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (fd < 0) {
		fprintf(stderr, "%s: socket failed\n", __func__);
		return ((void *)0);
	}
	salen = sizeof(struct sockaddr_in6);
	bzero(&sa, salen);
	sa.sin6_family = AF_INET6;
	sa.sin6_port = htons(OBU_BW_TEST_RESP_PORT);
	if (bind(fd, (struct sockaddr *)&sa, salen) < 0) {
		fprintf(stderr, "%s: bind failed\n", __func__);
		close(fd);
		return ((void *)0);
	}

	/**
	 * Receive bandwidth test request on OBU_BW_TEST_RESP_PORT
	 */
	while (1) {
		bzero(buf, BUFLEN);
		if ((len = recvfrom(fd, buf, BUFLEN, 0, (struct sockaddr *)&tmpsa, &salen)) < 0) {
			fprintf(stderr, "%s: recvfrom failed\n", __func__);
		} else {
			if (inet_ntop(AF_INET6, &tmpsa.sin6_addr, addr, salen) == 0) {
				warning("Get peer OBU's address failed");
				continue;
			}

			fprintf(stdout, "<%s> bw test request: %s\n", addr, buf);
			if (strncmp(buf, "BW-TEST", 7) == 0) {
				if (bw_test_resp(addr) < 0) {
					fprintf(stderr, "%s bw test response failed\n", __func__);
				}
			} else {
				fprintf(stderr, "%s recv wrong type bw test request\n", __func__);
			}
		}
	}

	close(fd);

	return ((void *)0);
}

/**
 * Bandwidth test
 */
int bw_test(const char *dstnode, const char *dstaddr, const char *seq)
{
	static struct cmd_info ci;
	int fd;
	struct sockaddr_in6 sa;
	int salen;
	char buf[BUFLEN];
	struct iovec iov;
	struct msghdr msg;
	union hoplimit_control hlc;
	unsigned char *cmdatap;

	fprintf(stderr, "Bandwidth test to %s <%s> seq %s\n",
			dstnode, dstaddr, seq);
	bzero(&ci, sizeof(ci));
	strcpy(ci.nodename, dstnode);
	strcpy(ci.nodeaddr, dstaddr);
	strcpy(ci.seq, seq);

	fd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (fd < 0) {
		warning("Socket");
		// TODO
		return -1;
	}
	salen = sizeof(struct sockaddr_in6);
	bzero(&sa, salen);
	sa.sin6_family = AF_INET6;
	sa.sin6_port = htons(OBU_BW_TEST_RESP_PORT);
	sa.sin6_scope_id = outif;
	if (inet_pton(AF_INET6, dstaddr, &sa.sin6_addr) != 1) {
		fprintf(stderr, "%s assign destIP address failed\n", __func__);
		// TODO
		close(fd);
		return -1;
	}
	iov.iov_base = buf;
	iov.iov_len = BUFLEN;
	bzero(buf, BUFLEN);
	bzero(&msg, sizeof(msg));
	msg.msg_name = (struct sockaddr *)&sa;
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	msg.msg_namelen = salen;
	bzero(&hlc, sizeof(hlc));
	msg.msg_control = hlc.control;
	msg.msg_controllen = sizeof(hlc.control);
	hlc.cmsg.cmsg_len = CMSG_LEN(sizeof(int));
	hlc.cmsg.cmsg_level = IPPROTO_IPV6;
	hlc.cmsg.cmsg_type = IPV6_HOPLIMIT;
	cmdatap = CMSG_DATA(&(hlc.cmsg));
	*((int *)cmdatap) = VANET_UC_HOPLIMIT_DEFAULT;

	/**
	 * Ask [nodename] sending test packet to me, using OBU_BW_TEST_RESP_PORT
	 */
	sprintf(buf, "BW-TEST request from %s\n", minename);
	if (sendmsg(fd, &msg, VANET_SENDMSG_FLAG) < 0) {
		fprintf(stderr, "ERROR: ask [%s] sending test packet to me failed\n", dstnode);
		// TODO if failed, we should give result 0 feedback to C&D
		close(fd);
		return -1;
	}

	do_bw_test(&ci);

	fprintf(stderr, "%s finished\n", __func__);
	close(fd);
	return 0;
}

/**
 * Listen C&D module's instructions or commands;
 * serving for C&D module;
 * and sending corresponding messages to peer OBU when needed.
 */
void serve_for_CD()
{
	char recvbuf[BUFLEN];
	char sendbuf[BUFLEN];
	int nrecv;
	struct msghdr msg; // Only for Unicast Text Messages
	struct iovec iov;
	union hoplimit_control hlc;
	unsigned char *cmdatap;
	char dstnode[NODE_NAME_LEN];
	char dstaddr[INET6_ADDRSTRLEN];
	char *data, *np;
	int i;
	struct msghdr msgbc; // Only for Broadcast Text Messages
	struct flowlabel_control fc;
	static unsigned int bcast_count = 1;
	int bcast;
	struct sigaction act, oact;

	iov.iov_base = sendbuf;
	iov.iov_len = BUFLEN;

	bzero(&msg, sizeof(msg));
	msg.msg_name = (struct sockaddr *)&obu_snd_sa;
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	msg.msg_namelen = obu_snd_salen;
	bzero(&hlc, sizeof(hlc));
	msg.msg_control = hlc.control;
	msg.msg_controllen = sizeof(hlc.control);
	hlc.cmsg.cmsg_len = CMSG_LEN(sizeof(int));
	hlc.cmsg.cmsg_level = IPPROTO_IPV6;
	hlc.cmsg.cmsg_type = IPV6_HOPLIMIT;
	cmdatap = CMSG_DATA(&(hlc.cmsg));
	*((int *)cmdatap) = VANET_UC_HOPLIMIT_DEFAULT;

	bzero(&msgbc, sizeof(msgbc));
	msgbc.msg_name = (struct sockaddr *)&obu_snd_bcast_sa;
	msgbc.msg_iov = &iov;
	msgbc.msg_iovlen = 1;
	msgbc.msg_control = &fc;
	bzero(&fc, sizeof(fc));
	msgbc.msg_controllen = sizeof(fc);
	fc.cmsg.cmsg_len = sizeof(fc);
	fc.cmsg.cmsg_level = IPPROTO_IPV6;
	fc.cmsg.cmsg_type = IPV6_FLOWINFO;
	msgbc.msg_namelen = obu_snd_bcast_salen;
	msgbc.msg_flags = 0;

	act.sa_handler = bw_test_sig_alrm;
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;
#ifdef SA_INTERRUPT
	act.sa_flags |= SA_INTERRUPT;
#endif
	if (sigaction(SIGALRM, &act, &oact) < 0) {
		warning("Signal");
		goto error;
	}

	while(1) {
		bzero(recvbuf, BUFLEN);
		nrecv = recvfrom(CD_lsn_fd, recvbuf, BUFLEN, 0, NULL, 0);
		if (nrecv < 0) {
			warning("Recvfrom C&D module failed");
			break;
		} else {
			fprintf(stderr, "DEBUG: %s recv %s\n", __func__, recvbuf);
			/**
			 * C&D send instruction to me, process entry blow.
			 * C&D's instruction format:
			 * "X [DSTNAME] DATA"
			 * X refers to instruction type.
			 */
			np = recvbuf + 3;

			// Get DSTNAME
			bzero(dstnode, NODE_NAME_LEN);
			for (i=0; i<NODE_NAME_LEN && *np!=']'; i++, np++)
				dstnode[i] = *np;
			// Get DATA
			for ( ; *np!=' '; np++)
				;
			data = np + 1;
			// Get DSTNAME node's IPv6 address
			bzero(dstaddr, INET6_ADDRSTRLEN);
			if (strcmp(dstnode, OBU_BCAST_NODE_NAME) == 0) { // broadcast
				strcpy(dstaddr, OBU_LISTEN_BCAST_ADDR);
				bcast = 1;
			} else { // unicast
				get_node_ip6addr(dstnode, dstaddr);
				bcast = 0;
			}

			// Start serve
			switch (recvbuf[0]) {
			case 'A': // Text message
				if (bcast) {
					text_message_send(&msgbc, dstaddr, data, 1, bcast_count);
					bcast_count++;
				} else {
					text_message_send(&msg, dstaddr, data, 0, 0);
				}
				break;
			case 'S': // RTT test
				if (bcast)
					fprintf(stderr, "ERROR: broadcast in RTT test\n");
				else
					rtt_test(dstnode, dstaddr, data);
				break;
			case 'B': // Bandwidth test
				if (bcast)
					fprintf(stderr, "ERROR: broadcast in Bandwidth test\n");
				else
					bw_test(dstnode, dstaddr, data);
				break;
			default:
				fprintf(stderr, "unknown message from C&D [%d]: %u\n", nrecv, recvbuf[0]);
				fprintf(stderr, "\t\t%s\n", recvbuf);
				break;
			}
			fprintf(stderr, "DEBUG: %s finished\n", __func__);
		}
	}

error:
	close_all_fd();
	exit(-1);
}

int main(int argc, char *argv[])
{
	pthread_t tid;
	int ret;

	if ((argc != 2) && (argc != 3)) {
		fprintf(stderr, "Usage: %s <nodename> [C&D address]\n", argv[0]);
		fprintf(stderr, "ATTENTION: <nodename> should be the same as joinvanet's argument.\n");
		fprintf(stderr, "\t   [C&D address] can be empty, (default is 192.168.10.200)\n");
		return -1;
	}
	if (strlen(argv[1]) > NODE_NAME_LEN - 1) {
		fprintf(stderr, "nodename is too long\n");
		return -1;
	}
	sprintf(minename, "%s", argv[1]);

	// Initial OBU <-> C&D related stuff.
	if (argc == 2)
		ret = init_CD_rel(CTRL_DISP_ADDRESS);
	else
		ret = init_CD_rel(argv[2]);
	if (ret < 0) {
		fprintf(stderr, "C&D fd initial failed\n");
		goto out;
	}

	// Initial OBU <-> OBU related stuff.
	if (init_obu_rel() < 0) {
		fprintf(stderr, "Peer OBU fd initial failed\n");
		goto out;
	}

	if (pthread_create(&tid, NULL, thr_lsn_peer_obu, NULL) != 0) {
		warning("Listen peer OBU thread start failed");
		goto out;
	}
	if (pthread_detach(tid) != 0) {
		warning("Detach thr_lsn_peer_obu failed");
		goto out;
	}

	if (pthread_create(&tid, NULL, thr_lsn_broadcast_obu, NULL) != 0) {
		warning("Listen broadcast OBU thread start failed");
		goto out;
	}
	if (pthread_detach(tid) != 0) {
		warning("Detach thr_lsn_broadcast_obu failed");
		goto out;
	}

	// Initial OBU's bandwidth test thread.
	if (pthread_create(&tid, NULL, thr_resp_bw_test, NULL) != 0) {
		warning("Bandwidth test response thread start failed");
		goto out;
	}
	if (pthread_detach(tid) != 0) {
		warning("Detach thr_resp_bw_test failed");
		goto out;
	}

	serve_for_CD();

out:
	close_all_fd();
	return 0;
}
