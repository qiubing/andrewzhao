#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "ipv6_cast.h"

int main(int argc, char *argv[])
{
	struct sockaddr_in sa;
	int fd, n;
	unsigned int salen;
	char nodename[NODE_NAME_LEN];
	char buf[BUFLEN];
	struct in6_addr nodeip;
	char addrstr[INET6_ADDRSTRLEN];

	if (argc != 2) {
		printf("Usage: %s <nodename>\n", argv[0]);
		return -1;
	}

	memset(nodename, 0, NODE_NAME_LEN);
	n = strlen(argv[1]);
	if (n >= NODE_NAME_LEN)
		n = NODE_NAME_LEN - 1;
	memcpy(nodename, argv[1], n);
	nodename[n] = 0;
	n++;

	salen = sizeof(struct sockaddr_in);
	memset(&sa, 0, salen);
	sa.sin_family = AF_INET;
	sa.sin_port = htons(NI_QUERY_SERVER_PORT);
	if (inet_pton(AF_INET, NI_QUERY_SERVER_IP, &sa.sin_addr) != 1)
		error("Assign destIP addr\n");
	if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		error("Socket");
	if (connect(fd, (struct sockaddr *)&sa, salen) != 0) {
		close(fd);
		error("Connect failed");
	}
	memset(buf, 0, BUFLEN);
	sprintf(buf, "A %s", nodename);
	send(fd, buf, n+2, 0);
	n = recv(fd, &nodeip, sizeof(struct in6_addr), 0);
	if (n < sizeof(struct in6_addr)) {
		close(fd);
		error("Get ipv6 address failed");
	}
	printf("%s\n", inet_ntop(AF_INET6, &nodeip, addrstr, INET6_ADDRSTRLEN));

	return 0;
}
