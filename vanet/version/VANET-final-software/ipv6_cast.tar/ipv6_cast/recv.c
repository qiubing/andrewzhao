#include<stdio.h>
#include<unistd.h>
#include<net/if.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<errno.h>
#include<stdlib.h>

#include"ipv6_cast.h"

FILE *recv_result_fp;

static void sig_handler_recv(int signo)
{
	if ((signo == SIGINT) || (signo == SIGTERM)) {
		fprintf(stderr, "Recv stopping...\n");
		fclose(recv_result_fp);
		exit(0);
	}
}

void usage(const char *command)
{
	printf("Usage: %s dev_name multicast_address port result_file\n", command);
	exit(0);
}

int parse_vm_to_ni(char buf[], struct node_info *nip)
{
	char *p, *s;
	int n = 0;

	if ((nip==NULL) || (buf==NULL))
		return -1;

	for (p=buf; (*p)!='\0'; ) {
		if ((*p) == ' ')
			n++;
		p++;
		if ((n==2) && ((*p)=='V')) {
			break;
		} else if (n == 2){
			return -1;
		}
	}
	for (p=p+2; (*p)!=' '; p++)
		;
	s = p+1;
	for (p=s, n=0; (*p)!=' '; p++, n++)
		;
	n = n+2;
	memcpy(nip->lat, s, n);
	nip->lat[n] = 0;

	p = p+3;
	s = p;
	for (n=0; (*p)!=' '; p++, n++)
		;
	n = n+2;
	memcpy(nip->lon, s, n);
	nip->lon[n] = 0;

	p = p+3;
	s = p;
	for (n=0; (*p)!=' '; p++, n++)
		;
	memcpy(nip->speed, s, n);
	nip->speed[n] = 0;

	p = p+1;
	s = p;
	for (n=0; (*p)!='\0'; p++, n++)
		;
	memcpy(nip->direction, s, n);
	nip->direction[n] = 0;
//	fprintf(stderr, "%s: lat<%s> lon<%s> speed<%s> direction<%s>\n",
//			__func__, nip->lat, nip->lon, nip->speed, nip->direction);
	return 0;
}

int main(int argc, char *argv[])
{
	int sockfd, CD_fd = -1, nsend, len;
	struct sockaddr_in6 recvsa, sendsa;
	unsigned int salen;
	char buf[BUFLEN];
	char rcvres[BUFLEN_SHORT];
	char ipaddr[INET6_ADDRSTRLEN];
	struct ipv6_mreq mreq6;
	char addr[INET6_ADDRSTRLEN];
	unsigned short port;
	char devname[BUFLEN_SHORT];
	pthread_t tid;
	int fail_count = 0;

	struct node_info_stack ni_stack; // store node info
	char nname[NODE_NAME_LEN];
	struct node_info *nip;

	if (argc != 5)
		usage(argv[0]);

	port = atoi(argv[3]);
	strcpy(devname, argv[1]);
	strcpy(ipaddr, argv[2]);
	strcpy(rcvres, argv[4]);
	printf("Listen-address:\t%s\nPort:\t\t%u\n", ipaddr, port);
	printf("Listen-device:\t%s\n", devname);
	printf("Receive result:\t%s\n", rcvres);

	salen = sizeof(struct sockaddr_in6);
	sockfd = socket(AF_INET6, SOCK_DGRAM, 0);

	/* set recv sockaddr and bind to sockfd*/
	memset(&recvsa, 0, salen);
	recvsa.sin6_family = AF_INET6;
	recvsa.sin6_port = htons(port);
	if (bind(sockfd, (struct sockaddr *)&recvsa, salen) < 0) {
		close(sockfd);
		error("Bind failed");
	}

	/* multicast group join */
	if ((mreq6.ipv6mr_interface = if_nametoindex(devname)) == 0)
	       warning("Parse interface name to index:");
	printf("IF index:\t%u\n", mreq6.ipv6mr_interface);
	if (inet_pton(AF_INET6, ipaddr, &mreq6.ipv6mr_multiaddr) != 1)
		error("Invalid IP addr");
	setsockopt(sockfd, IPPROTO_IPV6, IPV6_JOIN_GROUP, &mreq6, sizeof(mreq6));

	/* open recveive result file */
	if ((recv_result_fp = fopen(rcvres, "a")) == NULL) {
		error("Recveive result file open failed");
	}
	if (signal(SIGINT, sig_handler_recv) == SIG_ERR)
		error("register SIGINT handler failed");
	if (signal(SIGTERM, sig_handler_recv) == SIG_ERR)
		error("register SIGTERM handler failed");

	/**
	 * Control & Display module initial stuff
	 */
	CD_fd = udp_connect(CTRL_DISP_ADDRESS, CTRL_DISP_PORT);
	if (CD_fd < 0) {
		fprintf(stderr, "%s: udp connect to %s <%d> failed\n", __func__,
				CTRL_DISP_ADDRESS, CTRL_DISP_PORT);
	}

	if (pthread_mutex_init(&ni_stack.lock, NULL) != 0) {
		close(sockfd);
		error("pthread_mutex_init failed\n");
	}
	ni_stack.top = NULL;
	ni_stack.count = 0;

	if (pthread_create(&tid, NULL, thr_ni_query_server, &ni_stack) != 0) {
		close(sockfd);
		error("pthread_create failed\n");
	}

	while (1) {
		memset(buf, 0, BUFLEN);
		if (recvfrom(sockfd, buf, BUFLEN, 0, (struct sockaddr *)&sendsa, &salen) < 0)
			warning("Recvfrom failed");
		else {
			if (inet_ntop(AF_INET6, &sendsa.sin6_addr, addr, salen) == 0)
				warning("Get sender address failed");

			/*
			 * XXX TODO: start point of recv's modification
			 */

			// Print in PowerPC console
			fprintf(stderr, "RECV: <%s> %s", addr, buf);

			// Send other OBUs' GPS information to my C&D
			len = strlen(buf);
			nsend = sendto(CD_fd, buf, len, MSG_DONTWAIT, NULL, 0);
			if (nsend < 0) {
				if (fail_count <=0) {
					warning("Sendto Control & Display module failed");
					fail_count = CTRL_DISP_RETRY_INTERVAL * 50;
					// re-connect to C&D module
					CD_fd = udp_connect(CTRL_DISP_ADDRESS, CTRL_DISP_PORT);
					if (CD_fd < 0) {
						fprintf(stderr, "%s: udp connect to %s <%d> failed\n",
								__func__, CTRL_DISP_ADDRESS, CTRL_DISP_PORT);
					}
				}
				fail_count--;
			} else if (nsend != len) {
				warning("Data truncated");
			}

			/*
			 * Node info update.
			 */
			memset(nname, 0, NODE_NAME_LEN);
			get_node_name(buf, nname);
			pthread_mutex_lock(&ni_stack.lock);
			if ((nip = find_ni(&ni_stack, nname)) != NULL) { // find node and do not need adding.
				parse_vm_to_ni(buf, nip);
				pthread_mutex_unlock(&ni_stack.lock);
			} else {
				pthread_mutex_unlock(&ni_stack.lock);
				nip = new_ni(nname, &sendsa.sin6_addr);
				if (NULL == nip) {
					fprintf(stderr, "add new node info failed\n");
				} else {
					parse_vm_to_ni(buf, nip);
					push_ni_thread_safe(&ni_stack, nip);
				}
			}
			nip = NULL;

			fprintf(recv_result_fp, "%s", buf);
		}
	}

	close(CD_fd);
	close(sockfd);
	fclose(recv_result_fp);

	return 0;
}
