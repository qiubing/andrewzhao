#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <net/if.h>
#include <stdlib.h>

#include "ipv6_cast.h"

FILE *send_result_fp;

static void sig_handler_send(int signo)
{
	if ((signo == SIGINT) || (signo == SIGTERM)) {
		fprintf(stderr, "Send stopping...\n");
		fclose(send_result_fp);
		exit(0);
	}
}

void usage(const char *command)
{
	printf("Usage: %s dev_name multicast_address port loopback hop_limit [s|u]seconds gps nodename result_file\n", command);
	exit(0);
}

pthread_mutex_t parsed_gps_info_lock = PTHREAD_MUTEX_INITIALIZER;

int main(int argc, char *argv[])
{
	int sockfd;
	char sendbuf[BUFLEN];
	struct sockaddr_in6 sa;
	struct msghdr msg;
	struct flowlabel_control fc;
	unsigned int fl;
	struct iovec iov;
	static unsigned int count = 1;
	unsigned int outif, loopback;
	unsigned short port;
	char ipaddr[INET6_ADDRSTRLEN], devname[BUFLEN_SHORT];
	char nodename[NODE_NAME_LEN];
	int hops, interval, gpson;
	pthread_t tid;
	char sndres[BUFLEN_SHORT];

	if (argc != 10)
		usage(argv[0]);

	port = atoi(argv[3]);
	strcpy(devname, argv[1]);
	strcpy(ipaddr, argv[2]);
	strcpy(nodename, argv[8]);
	strcpy(sndres, argv[9]);
	hops = atoi(argv[5]);
	if (argv[6][0] == 'u' || argv[6][0] == 's')
		interval = atoi(&argv[6][1]);
	else
		interval = atoi(argv[6]);

	if (argv[4][0] == '0') loopback = 0;
	else loopback = 1;
	if (argv[7][0] == '0') gpson = 0;
	else gpson = 1;

	strcpy(parsed_gps_info, VANET_DEFAULT_MSG);
	/*
	 * create thread for gps information parse.
	 */
	if (gpson) {
		if (pthread_create(&tid, NULL, thr_parse_gpsinfo, NULL) != 0) {
			error("thread create failed\n");
		}
	}

	printf("Node name:\t%s\n", nodename);
	printf("Brdcst-address:\t%s\nPort:\t\t%u\n", ipaddr, port);
	printf("Brdcst-device:\t%s\n", devname);
	printf("Result-file:\t%s\n", sndres);

	sockfd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (sockfd < 0)
		error("Socket");

	/* multicast IF set */
	if ((outif = if_nametoindex(devname)) == 0)
		warning("Parse name to ifindex failed");
	printf("IF index:\t%u\n", outif);
	setsockopt(sockfd, IPPROTO_IPV6, IPV6_MULTICAST_IF, &outif, sizeof(outif));

	/* loopback forbidden*/
	printf("Loopback:\t%s\n", (loopback==0)? "off":"on");
	setsockopt(sockfd, IPPROTO_IPV6, IPV6_MULTICAST_LOOP, &loopback, sizeof(loopback));

	/* set hop_limit */
	printf("Hop_limit:\t%d\n", hops);
	setsockopt(sockfd, IPPROTO_IPV6, IPV6_MULTICAST_HOPS, &hops, sizeof(hops));

	/* set sockaddr of destination */
	memset(&sa, 0, sizeof(sa));
	sa.sin6_family = AF_INET6;
	sa.sin6_port = htons(port);
	if (inet_pton(AF_INET6, ipaddr, &sa.sin6_addr) != 1)
		error("Assign destIP addr");

	/* open send result file */
	if ((send_result_fp = fopen(sndres, "a")) == NULL) {
		error("Send result file open failed");
	}
	if (signal(SIGINT, sig_handler_send) == SIG_ERR)
		error("register SIGINT handler failed");
	if (signal(SIGTERM, sig_handler_send) == SIG_ERR)
		error("register SIGTERM handler failed");

	/* set sendmsg parameters*/
	iov.iov_base = sendbuf;
	iov.iov_len = sizeof(sendbuf);
	msg.msg_name = (struct sockaddr *)&sa;
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	msg.msg_control = &fc;
	msg.msg_controllen = sizeof(fc);
	fc.cmsg.cmsg_len = sizeof(fc);
	fc.cmsg.cmsg_level = IPPROTO_IPV6;
	fc.cmsg.cmsg_type = IPV6_FLOWINFO;
	msg.msg_namelen = sizeof(sa);
	msg.msg_flags = 0;

	while(1) {
		memset(sendbuf, 0, sizeof(sendbuf));
		if (argv[6][0] == 'u')
			usleep(interval);
		else
			sleep(interval);
		fl = htonl(count & 0xfffff);
		memset(&fc.cmsg_data, 0, sizeof(fc.cmsg_data));

		memcpy(&fc.cmsg_data, (unsigned char*)&fl, sizeof(fc.cmsg_data));

		pthread_mutex_lock(&parsed_gps_info_lock);
		sprintf(sendbuf, "[%s] [%u] %s", nodename, count, parsed_gps_info);
		pthread_mutex_unlock(&parsed_gps_info_lock);

		count++;

//		printf("%s", sendbuf);
		fprintf(send_result_fp, "%s", sendbuf);
		iov.iov_len = strlen(sendbuf);
		if (sendmsg(sockfd, &msg, 0) < 0) {
			fprintf(stderr, "-----------------------------------\n");
			warning("Assign source IPv6 address failed, retrying...");
		}
	}

	close(sockfd);
	fclose(send_result_fp);

	return 0;
}
