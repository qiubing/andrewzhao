#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>

#include "ipv6_cast.h"

struct node_info *new_ni(char *name, struct in6_addr *addr)
{
	struct node_info *p;
	int namelen;

	printf("%s name: %s\n", __func__, name);
	namelen = strlen(name);
	if (namelen > (NODE_NAME_LEN - 1)) {
		warning("node name's length too long, cut!\n");
		namelen = NODE_NAME_LEN - 1;
	}

	p = (struct node_info *)malloc(sizeof(struct node_info));
	if (NULL == p) {
		warning("memory allocate failed\n");
	} else {
		memset(p, 0, sizeof(struct node_info));
		memcpy(p->name, name, namelen);
		memcpy(&(p->ip6addr), addr, sizeof(struct in6_addr));
		p->alive = NODE_KEEP_ALIVE;
	}

	return p;
}

/*
 * failed, return -1; and success, return 0.
 * node's ipv6 address is in addr.
 */
int get_ni_addr_thread_safe(struct node_info_stack *nis, char *name, struct in6_addr *addr)
{
	struct node_info *pp, *p, *d;
	int val = -1;

	pthread_mutex_lock(&nis->lock);
	for (pp=NULL, p=nis->top; p!=NULL; ) {
		if ((!strcmp(p->name, name)) && val) { //find it
			memcpy(addr, &(p->ip6addr), sizeof(struct in6_addr));
			val = 0;
			pp = p;
			p = p->next;
		} else {
			p->alive--;
			if (p->alive <= 0) { //delete node p
				printf("%s delete: %s\n", __func__, p->name);
				d = p;
				p = p->next;
				if (pp != NULL) {
					pp->next = p;
				} else {
					nis->top = p;
				}
				nis->count--;
				free(d);
			} else {
				pp = p;
				p = p->next;
			}
		}
	}
	pthread_mutex_unlock(&nis->lock);

	return val;
}

/*
 * do not find ni, return NULL;
 */
struct node_info *find_ni(struct node_info_stack *nis, char *name)
{
	struct node_info *p, *val=NULL;

	for (p=nis->top; p!=NULL; p=p->next) {
		if (!strcmp(p->name, name)) {
			p->alive = NODE_KEEP_ALIVE;
			val = p;
			break;
		} else {
			p->alive--;
		}
	}

	return val;
}

void push_ni_thread_safe(struct node_info_stack *nis, struct node_info *ni)
{
	printf("Pushing new node [%s] into ni_stack\n", ni->name);
	pthread_mutex_lock(&nis->lock);
	ni->next = nis->top;
	nis->top = ni;
	nis->count++;
	pthread_mutex_unlock(&nis->lock);
}

void *thr_ni_query_server(void *arg)
{
	struct node_info_stack *nis;
	struct node_info *nip;
	struct sockaddr_in serversa;
	int sockfd, clfd, nrecv;
	unsigned int salen;
	char buf[BUFLEN];
	char nodename[NODE_NAME_LEN];
	struct in6_addr nodeip;

	if (NULL == arg)
		error("node info query server get wrong arg\n");
	nis = (struct node_info_stack *)arg;

	salen = sizeof(struct sockaddr_in);
	memset(&serversa, 0, salen);
	serversa.sin_family = AF_INET;
	serversa.sin_port = htons(NI_QUERY_SERVER_PORT);
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		error("socket failed\n");
	if (bind(sockfd, (struct sockaddr *)&serversa, salen) < 0) {
		close(sockfd);
		error("bind failed\n");
	}
	if (listen(sockfd, 3) < 0) {
		close(sockfd);
		error("listen failed\n");
	}

	while(1) {
		clfd = accept(sockfd, NULL, NULL);
		if (clfd < 0) {
			warning("accept failed\n");
			continue;
		}
		memset(buf, 0, BUFLEN);
		memset(nodename, 0, NODE_NAME_LEN);
		memset(&nodeip, 0, sizeof(struct in6_addr));
		nrecv = recv(clfd, buf, BUFLEN, 0);
		if (nrecv <=0 ) {
			warning("server receive request error\n");
			close(clfd);
			continue;
		}
		switch(buf[0]) {
		case 'A': // address
			if (nrecv > NODE_NAME_LEN + 2)
				nrecv = NODE_NAME_LEN + 2;
			memcpy(nodename, buf+2, nrecv-2);
			nodename[nrecv-3] = '\0';
			printf("Nodeinfo query server: receive request: %s\n", nodename);
			if (get_ni_addr_thread_safe(nis, nodename, &nodeip) < 0) {
				printf("Nodeinfo query server: do not find %s IPv6 address\n", nodename);
			}
			send(clfd, &nodeip, sizeof(struct in6_addr), 0);
			break;
		case 'I': // all information
			if (nrecv > NODE_NAME_LEN +2)
				nrecv = NODE_NAME_LEN + 2;
			memcpy(nodename, buf+2, nrecv-2);
			nodename[nrecv-3] = '\0';
			printf("Nodeinfo query server: receive request: %s\n", nodename);
			pthread_mutex_lock(&nis->lock);
			if ((nip=find_ni(nis, nodename)) != NULL) {
				memcpy(buf, nip, sizeof(*nip));
				pthread_mutex_unlock(&nis->lock);
				send(clfd, buf, sizeof(*nip), 0);
			} else {
				pthread_mutex_unlock(&nis->lock);
				printf("Nodeinfo query server: do not find %s\n", nodename);
				send(clfd, "NULL", 5, 0);
			}
			break;
		default:
			fprintf(stderr, "illegal request\n");
		}
		close(clfd);
	}

	return (void *)0;
}

/**
 * Translate node name to corresponding IPv6 address
 */
int get_node_ip6addr(char nodename[], char *addr)
{
	struct sockaddr_in sa;
	int fd, n;
	unsigned int salen;
	char buf[BUFLEN];
	struct in6_addr nodeip;
	char addrstr[INET6_ADDRSTRLEN];

	n = strlen(nodename);
	n++;

	salen = sizeof(struct sockaddr_in);
	memset(&sa, 0, salen);
	sa.sin_family = AF_INET;
	sa.sin_port = htons(NI_QUERY_SERVER_PORT);
	if (inet_pton(AF_INET, NI_QUERY_SERVER_IP, &sa.sin_addr) != 1)
		error("Assign destIP addr");
	if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		error("Socket");
	if (connect(fd, (struct sockaddr *)&sa, salen) != 0) {
		close(fd);
		error("Connect failed");
	}

	memset(buf, 0, BUFLEN);
	sprintf(buf, "A %s", nodename);
	send(fd, buf, n+2, 0);
	n = recv(fd, &nodeip, sizeof(struct in6_addr), 0);
	if (n < sizeof(struct in6_addr)) {
		close(fd);
		error("Get ipv6 address failed");
	}
	sprintf(addr, "%s", inet_ntop(AF_INET6, &nodeip, addrstr, INET6_ADDRSTRLEN));

	return 0;
}

