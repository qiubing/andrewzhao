#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>

#include "ipv6_cast.h"

void error(const char *msg)
{
	perror(msg);
	exit(-1);
}

void warning(const char *msg)
{
	perror(msg);
}

void get_node_name(const char *buf, char *name)
{
	int i;

	for (i=1; i<strlen(buf); i++) {
		if (buf[i] == ']')
			break;
	}
	if (i > NODE_NAME_LEN)
		i = NODE_NAME_LEN;
	memcpy(name, buf+1, i-1);
	name[i-1] = '\0';
}

/**
 * With the help of connect(), we can using NULL in sendto()'s
 * destination sockaddr dest_addr field.
 */
int udp_connect(const char *addr, int port)
{
        int sockfd;
        struct sockaddr_in sa;
        unsigned int salen;

        salen = sizeof(sa);
        bzero(&sa, salen);
        sa.sin_family = AF_INET;
        sa.sin_port = htons(port);
        if (inet_pton(AF_INET, addr, &sa.sin_addr) != 1) {
                warning("Address");
                return -1;
        }

        if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
                warning("Socket");
                return -1;
        }

        if (connect(sockfd, (struct sockaddr *)&sa, salen) < 0) {
                warning("Connect");
                close(sockfd);
                return -1;
        }

        return sockfd;
}

int udp_bind(const char *addr, int port)
{
        int sockfd;
        struct sockaddr_in sa; 
        unsigned int salen;

        salen = sizeof(sa);
        bzero(&sa, salen);
        sa.sin_family = AF_INET;
        sa.sin_port = htons(port);
        if (addr != NULL) {
                if (inet_pton(AF_INET, addr, &sa.sin_addr) != 1) {
                        warning("Address");
                        return -1;
                }   
        } else {
		fprintf(stdout, "%s: using INADDR_ANY\n", __func__);
                sa.sin_addr.s_addr = INADDR_ANY;
        }

        if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
                warning("Socket");
                return -1;
        }   

        if (bind(sockfd, (struct sockaddr *)&sa, salen) < 0) {
                warning("Bind");
                close(sockfd);
                return -1;
        }   

        return sockfd;
}

/**
 * RTT test related
 */
void tv_sub(struct timeval *in, struct timeval *out)
{
	if ((in->tv_usec -= out->tv_usec) < 0) {
		--in->tv_sec;
		in->tv_usec += 1000000;
	}
	in->tv_sec -= out->tv_sec;
}
