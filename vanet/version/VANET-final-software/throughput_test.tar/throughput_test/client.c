#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <net/if.h>
#include <stdlib.h>
#include <arpa/inet.h>

#define VANET_SENDMSG_FLAG 0x20000

#define BUFLEN 1000 // for 1KB

union hoplimit_control {
	struct cmsghdr cmsg;
	char control[CMSG_SPACE(sizeof(int))];
};

int sockfd;
char sendbuf[BUFLEN];
struct sockaddr_in6 sa;
struct msghdr msg;
struct iovec iov;
unsigned short port;
unsigned int outif;
union hoplimit_control hlc;
unsigned char *cmdatap;
int hop;
int rate;
int sec;
int usec;
double tmp;
struct itimerval itval;

void sig_alrm(int signo);

int main(int argc, char *argv[])
{
	if (argc != 6) {
		printf("Usage: %s destaddr destport hop_limit devicename N(KBps)\n", argv[0]);
		return -1;
	}
	rate = atoi(argv[5]);
	if (rate > 1) {
		sec = 0;
		tmp = 1000000.0 / ((double)rate);
		usec = (int)tmp;
	} else if (rate == 1) {
		sec = 1;
		usec = 0;
	} else {
		fprintf(stderr, "Wrong input\n");
		exit (-1);
	}
	itval.it_value.tv_sec = 1;
	itval.it_value.tv_usec = 0;
	itval.it_interval.tv_sec = sec;
	itval.it_interval.tv_usec = usec;

	port = atoi(argv[2]);
	hop = atoi(argv[3]);
	printf("Dest address is %s, port is %u, hop_limit is %d, devname %s\n", argv[1], port, hop, argv[4]);
	sockfd = socket(AF_INET6, SOCK_DGRAM, 0);
	if (sockfd < 0) {
		printf("Socket failed\n");
		return -1;
	}
	if ((outif = if_nametoindex(argv[4])) == 0) {
		printf("Parse devname %s to ifindex failed\n", argv[4]);
		close(sockfd);
		return -1;
	}
	printf("Output ifindex = %u, Wanna rate = %d KBps\n", outif, rate);

	memset(&sa, 0, sizeof(sa));
	sa.sin6_family = AF_INET6;
	sa.sin6_port = htons(port);
	sa.sin6_scope_id = outif;
	if (inet_pton(AF_INET6, argv[1], &sa.sin6_addr) != 1) {
		printf("Assign destIP addr failed\n");
		return -1;
	}
	iov.iov_base = sendbuf;
	iov.iov_len = sizeof(sendbuf);
	memset(sendbuf, 0, sizeof(sendbuf));
	memset(&msg, 0, sizeof(msg));
	msg.msg_name = (struct sockaddr *)&sa;
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	msg.msg_namelen = sizeof(sa);

	memset(&hlc, 0, sizeof(hlc));
	msg.msg_control = hlc.control;
	msg.msg_controllen = sizeof(hlc.control);
	hlc.cmsg.cmsg_len = CMSG_LEN(sizeof(int));
	hlc.cmsg.cmsg_level = IPPROTO_IPV6;
	hlc.cmsg.cmsg_type = IPV6_HOPLIMIT;
	cmdatap = CMSG_DATA(&(hlc.cmsg));
	*((int *)cmdatap) = hop;

	if (signal(SIGALRM, sig_alrm) == SIG_ERR) {
		fprintf(stderr, "Register signal handler failed\n");
		close(sockfd);
		exit(-1);
	}

	if (setitimer(ITIMER_REAL, &itval, NULL) < 0) {
		fprintf(stderr, "Setitimer failed\n");
		close(sockfd);
		exit(-1);
	}

	for (;;)
		pause();
	close(sockfd);

	return 0;
}

void sig_alrm(int signo)
{
	if (signo != SIGALRM) {
		fprintf(stderr, "Catched unknown signal %d\n", signo);
		return ;
	}
	if (sendmsg(sockfd, &msg, VANET_SENDMSG_FLAG) < 0) {
		printf("Send information failed\n");
		close(sockfd);
		exit(-1);
	}
}
