#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

static int total_bytes = 0;
static double rate = 0;
static int count = 1;

/* SIGALRM generated every 1 sec */
void sig_alrm(int signo)
{
	if (signo != SIGALRM) {
		fprintf(stderr, "Unknown signo = %d\n", signo);
		return ;
	}
	rate = total_bytes / 1000.0;
	if (total_bytes != 0) {
		fprintf(stderr, "[%3d] receiving data rate: %.3f KB/sec\n", count, rate);
		count++;
		total_bytes = 0;
		rate = 0;
	}

	return ;
}

int main(int argc, char *argv[])
{
	int sockfd;
	struct sockaddr_in6 recvsa, sendsa;
	unsigned int salen;
	char buf[1500];
	char addr[32];
	unsigned short port;
	int nrecv = 0;
	struct itimerval itval;

	if (argc != 2) {
		printf("Usage: %s port\n", argv[0]);
		return -1;
	}

	port = atoi(argv[1]);
	salen = sizeof(struct sockaddr_in6);
	sockfd = socket(AF_INET6, SOCK_DGRAM, 0);

	memset(&recvsa, 0, salen);
	recvsa.sin6_family = AF_INET6;
	recvsa.sin6_port = htons(port);
	if (bind(sockfd, (struct sockaddr *)&recvsa, salen) < 0) {
		printf("Bind failed\n");
		close(sockfd);
		return -1;
	}

	if (signal(SIGALRM, sig_alrm) == SIG_ERR) {
		fprintf(stderr, "Register signal handler failed\n");
		close(sockfd);
		return -1;
	}
	itval.it_value.tv_sec = 1;
	itval.it_value.tv_usec = 0;
	itval.it_interval.tv_sec = 1;
	itval.it_interval.tv_usec = 0;
	if (setitimer(ITIMER_REAL, &itval, NULL) < 0) {
		fprintf(stderr, "Setitimer failed\n");
		close(sockfd);
		return -1;
	}

	while(1) {
		if ((nrecv = recvfrom(sockfd, buf, sizeof(buf), 0, (struct sockaddr *)&sendsa, &salen)) < 0) {
			nrecv = 0;
			printf("Recvfrom failed\n");
		} else {
			if (inet_ntop(AF_INET6, &sendsa.sin6_addr, addr, salen) == 0) {
				printf("Get sender address failed\n");
			}
//				printf("RECV: <%s> %s", addr, buf);
		}
		total_bytes += nrecv;
	}
	close(sockfd);

	return 0;
}
